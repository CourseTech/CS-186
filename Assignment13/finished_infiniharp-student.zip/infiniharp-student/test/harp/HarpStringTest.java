/*
 * Copyright 2019 Marc Liberatore.
 */
package harp;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class HarpStringTest {

	@Test
	public void testNewString() {
		double[] values = { 0.5, 0.4, 0.3, 0.2, 0.1 };
		HarpString s = new HarpString(values);
		assertEquals(0, s.time());
		assertEquals(0.5, s.sample(), 0);
	}

	@Test
	public void testStringTic() {
		double[] values = { 0.5, 0.4, 0.3, 0.2, 0.1 };
		HarpString s = new HarpString(values);
		assertEquals(0, s.time());
		assertEquals(0.5, s.sample(), 0);
		s.tic();
		assertEquals(1, s.time());
		assertEquals(0.4, s.sample(), 0);
	}

	@Test
	public void testStringManyTics() {
		double[] values = { 0.5, -0.4, 0.3, -0.2, 0.1 };
		double[] expected = { 0.5, -0.4, 0.3, -0.2, 0.1, -0.04969999999999999, 0.049700000000000015,
				-0.04969999999999999, 0.0497, -0.02499910000000001, -1.379452108096757E-17, -1.379452108096757E-17,
				-6.897260540483785E-18, -0.012276347299999995, 0.012424552700000011, 1.3711753954481765E-17,
				1.0283815465861325E-17, 0.006101344608100001, -7.365808380000793E-5, -0.006175002691900013,
				-1.1925798001910514E-17, -0.0030323682702257057, -0.0029957602025770967, 0.00310558440552291,
				0.0030689763378743125, 0.0015070870303021816, 0.002995979850982993, -5.4582628864069305E-5,
				-0.00306875668946842, -0.0022743034939837177, -0.002238024239998732, -0.001461874419393105,
				0.0015522996412112473, 0.0026555009111757124, 0.002242626883789277, 0.001838849633717743,
				-4.4941335243616717E-5, -0.002091276874536319, -0.0024343695140976, -0.0020284938292009893,
				-8.915724243416408E-4, 0.0010617004502606283, 0.002249246255151058, 0.002218043081619399,
				0.0014512729280106872, -8.45536288817368E-5, -0.0016455405125896082, -0.0022202428003749173,
				-0.0018236500567861528, -6.792594916670883E-4, };
		HarpString s = new HarpString(values);
		for (int i = 0; i < expected.length; i++) {
			assertEquals(i, s.time());
			assertEquals(expected[i], s.sample(), 0);
			System.out.println(s.sample());
			s.tic();
		}
	}

}
