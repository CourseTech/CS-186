/*
 * Copyright 2019 Marc Liberatore.
 */
package queue;

import java.util.ArrayDeque;
import java.util.NoSuchElementException;
import java.util.Queue;

/**
 * 
 * A specialized implementation of an array-based circular queue of doubles.
 * 
 * @author liberato
 *
 */
public class CircularDoublesQueue {
	int maxCapacity = 0;
	double[] queue;
	int front;
	int rear;
	int size;
	
	/**
	 * Create an empty circular queue of doubles, with the given maximum capacity.
	 */
	public CircularDoublesQueue(int maxCapacity) {
		queue = new double[maxCapacity];
		size = 0;
		front = 0;
		rear = maxCapacity - 1;
		this.maxCapacity = maxCapacity;
	}

	/**
	 * Returns the number of elements in this queue.
	 */
	public int size() {
		return size;
	}

	/**
	 * Returns true if this queue contains no elements.
	 */
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * Returns true if enqueuing on this queue will exceed its maximum capacity.
	 */
	public boolean isFull() {
		return size == maxCapacity;
	}

	/**
	 * Inserts the specified value at the end of this queue if it is possible to do
	 * so immediately without violating capacity restrictions, throwing an
	 * IllegalStateException if no space is currently available.
	 */
	public void enqueue(double d) {
		if(this.isFull()){
			throw new IllegalStateException();
		}
		rear = (rear + 1) % queue.length;
		queue[rear] = d;
		size++;
	}

	/**
	 * Retrieves and removes the first element of this queue, throwing a
	 * NoSuchElement exception if this queue is empty.
	 */
	public double dequeue() {
		if(this.isEmpty()){
			throw new NoSuchElementException();
		}
		double value = queue[front];
		front = (front + 1) % queue.length;
		size--;
		return value;
	}

	/**
	 * Retrieves but does not remove the first element of this queue, throwing a
	 * NoSuchElement exception if this queue is empty.
	 */
	public double peek() {
		if(this.isEmpty()){
			throw new NoSuchElementException();
		}
		return queue[front];
	}

}
