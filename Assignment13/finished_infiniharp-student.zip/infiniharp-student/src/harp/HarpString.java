/*
 * Copyright 2019 Marc Liberatore.
 */
package harp;

import java.util.Random;

import queue.CircularDoublesQueue;

/**
 * A simulated harp string, built using the Karplus-Strong algorithm. Sounds like
 * a synthesizer from the 80s, because that's what it is. 
 * 
 * You'll need to look at the assignment writeup to implement these methods 
 * correctly.
 * 
 * @author liberato
 *
 */
public class HarpString {
	private final int SAMPLING_RATE = 44100;
	private final double DECAY_FACTOR = -0.994;
	CircularDoublesQueue queue;
	int count = 0;
	
	/**
	 * Create a harp string of the given frequency, using a sampling rate of
	 * 44,100 Hz; the string is created silent.
	 */
	public HarpString(double frequency) {
		int maxCapacity = (int) (SAMPLING_RATE/frequency) + 1;
		CircularDoublesQueue queue = new CircularDoublesQueue(maxCapacity);
		while(!queue.isFull()){
			queue.enqueue(0);
		}
		this.queue = queue;
	}

	/**
	 * Create a harp string whose size and initial values are given by the array.
	 */
	public HarpString(double[] init) {
		CircularDoublesQueue queue = new CircularDoublesQueue(init.length);
		for(double element : init){
			queue.enqueue(element);
		}
		this.queue = queue;
	}

	/**
	 * Pluck the string by filling the buffer with white noise.
	 */
	public void pluck() {
		Random r = new Random(0);
		for(int i = 0; i < this.queue.size();i++){
			this.queue.dequeue();
			this.queue.enqueue(r.nextDouble() - 0.5);
		}
	}

	/**
	 * Advance the string simulation one step by running the Karplus-Strong
	 * algorithm.
	 */
	public void tic() {
		count ++;
		double first = this.queue.peek();
		this.queue.dequeue();
		double second = this.queue.peek();
		double result = DECAY_FACTOR * (0.5 *(first + second));
		this.queue.enqueue(result);
	}
	/**
	 * Return the current frequency sample from the string.
	 */
	public double sample() {
		return this.queue.peek();
	}

	/**
	 * Return the number of tics passed since this object was initialized.
	 */
	public int time() {
		return this.count;
	}
	
}
