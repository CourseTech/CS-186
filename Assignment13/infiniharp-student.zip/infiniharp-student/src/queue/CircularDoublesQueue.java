/*
 * Copyright 2019 Marc Liberatore.
 */
package queue;

import java.util.NoSuchElementException;

/**
 * 
 * A specialized implementation of an array-based circular queue of doubles.
 * 
 * @author liberato
 *
 */
public class CircularDoublesQueue {
	
	/**
	 * Create an empty circular queue of doubles, with the given maximum capacity.
	 */
	public CircularDoublesQueue(int maxCapacity) {
	}

	/**
	 * Returns the number of elements in this queue.
	 */
	public int size() {
		return 0;
	}

	/**
	 * Returns true if this queue contains no elements.
	 */
	public boolean isEmpty() {
		return false;
	}

	/**
	 * Returns true if enqueuing on this queue will exceed its maximum capacity.
	 */
	public boolean isFull() {
		return false;
	}

	/**
	 * Inserts the specified value at the end of this queue if it is possible to do
	 * so immediately without violating capacity restrictions, throwing an
	 * IllegalStateException if no space is currently available.
	 */
	public void enqueue(double d) {
	}

	/**
	 * Retrieves and removes the first element of this queue, throwing a
	 * NoSuchElement exception if this queue is empty.
	 */
	public double dequeue() {
		return 0.0;
	}

	/**
	 * Retrieves but does not remove the first element of this queue, throwing a
	 * NoSuchElement exception if this queue is empty.
	 */
	public double peek() {
		return 0.0;
	}
}
