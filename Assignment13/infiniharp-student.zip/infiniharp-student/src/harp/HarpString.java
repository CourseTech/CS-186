/*
 * Copyright 2019 Marc Liberatore.
 */
package harp;


/**
 * A simulated harp string, built using the Karplus-Strong algorithm. Sounds like
 * a synthesizer from the 80s, because that's what it is. 
 * 
 * You'll need to look at the assignment writeup to implement these methods 
 * correctly.
 * 
 * @author liberato
 *
 */
public class HarpString {
	private final int SAMPLING_RATE = 44100;
	private final double DECAY_FACTOR = -0.994;

	/**
	 * Create a harp string of the given frequency, using a sampling rate of
	 * 44,100 Hz; the string is created silent.
	 */
	public HarpString(double frequency) {
	}

	/**
	 * Create a harp string whose size and initial values are given by the array.
	 */
	public HarpString(double[] init) {
	}

	/**
	 * Pluck the string by filling the buffer with white noise.
	 */
	public void pluck() {
	}

	/**
	 * Advance the string simulation one step by running the Karplus-Strong
	 * algorithm.
	 */
	public void tic() {
	}

	/**
	 * Return the current frequency sample from the string.
	 */
	public double sample() {
		return 0.0;
	}

	/**
	 * Return the number of tics passed since this object was initialized.
	 */
	public int time() {
		return 0;
	}
}
