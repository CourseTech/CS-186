/*
 * Copyright 2019 Marc Liberatore.
 */
package queue;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.NoSuchElementException;
import java.util.Random;

import org.junit.Test;


public class CircularDoublesQueueTest {
	@Test
	public void testInitialize() {
		CircularDoublesQueue q = new CircularDoublesQueue(1);
	}
	
	@Test
	public void testEmpty() {
		CircularDoublesQueue q = new CircularDoublesQueue(1);
		assertTrue(q.isEmpty());
		q.enqueue(0);
		assertFalse(q.isEmpty());
		q.dequeue();
		assertTrue(q.isEmpty());
	}
	
}
