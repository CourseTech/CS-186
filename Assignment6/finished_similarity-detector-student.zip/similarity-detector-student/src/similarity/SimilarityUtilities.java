/*
 * Copyright 2017 Marc Liberatore.
 */

package similarity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import sets.SetUtilities;

public class SimilarityUtilities extends SetUtilities {
	/**
	 * Returns the set of non-empty lines contained in a text, trimmed of
	 * leading and trailing whitespace.
	 * 
	 * @param text
	 * @return the trimmed set of lines
	 */
	public static Set<String> trimmedLines(String text) {

		String[] linearray = text.split("\\n");

		Set<String> t = new HashSet<String>();
		for (String line : linearray) {
			String newline = line.trim();
			if (newline.length() > 0) {
				t.add(newline);
			}
		}
		return t;
	}

	/**
	 * Returns a list of words in the text, in the order they appeared in the
	 * text, converted to lowercase.
	 * 
	 * Words are defined as a contiguous sequence of letters and numbers.
	 *
	 * @param text
	 * @return a list of lowercase words
	 */
	public static List<String> asLowercaseWords(String text) {
		List<String> t = new ArrayList<String>();
		text = text.toLowerCase();
		String[] newtext = text.split("\\W+");
		for (String line : newtext) {
			String newline = line.trim();
			if (newline.length() > 0) {
				t.add(newline);
			}
		}
		return t;
	}

	/**
	 * Returns the line-based similarity of two texts.
	 * 
	 * The line-based similarity is the Jaccard index between each text's line
	 * set.
	 * 
	 * A text's line set is the set of trimmed lines in that text, as defined by
	 * trimmedLines.
	 * 
	 * @param text1
	 *            a text
	 * @param text2
	 *            another text
	 * @return
	 */
	public static double lineSimilarity(String text1, String text2) {
		Set<String> settext1 = new HashSet<String>(trimmedLines(text1));
		Set<String> settext2 = new HashSet<String>(trimmedLines(text2));
		double result = jaccardIndex(settext1, settext2);
		return result;
	}

	/**
	 * Returns the line-based similarity of two texts.
	 * 
	 * The line-based similarity is the Jaccard index between each text's line
	 * set.
	 * 
	 * A text's line set is the set of trimmed lines in that text, as defined by
	 * trimmedLines, less the set of trimmed lines from the templateText.
	 * Removes the template text from consideration after trimming lines, not
	 * before.
	 * 
	 * @param text1
	 *            a text
	 * @param text2
	 *            another text
	 * @param templateText
	 *            a template, representing things the two texts have in common
	 * @return
	 */
	public static double lineSimilarity(String text1, String text2, String templateText) {
		Set<String> settext1 = new HashSet<String>(trimmedLines(text1));
		Set<String> settext2 = new HashSet<String>(trimmedLines(text2));
		Set<String> settemp = new HashSet<String>(trimmedLines(templateText));
		settext1.removeAll(settemp);
		settext2.removeAll(settemp);
		double result = jaccardIndex(settext1, settext2);
		return result;
	}

	/**
	 * Returns a set of strings representing the shingling of the given length
	 * of a list of words.
	 * 
	 * A shingling of length k of a list of words is the set of all k-shingles
	 * of that list.
	 * 
	 * A k-shingle is the concatenation of k adjacent words.
	 * 
	 * For example, a 3-shingle of the list: ["a" "very" "fine" "young" "man"
	 * "I" "know"] is the set: {"averyfine" "veryfineyoung" "fineyoungman"
	 * "youngmanI" "manIknow"}.
	 * 
	 * @param words
	 * @param shingleLength
	 * @return
	 */
	public static Set<String> shingle(List<String> words, int shingleLength) {
		Set<String> result = new HashSet<>();
		for (int i = 0; i <= words.size() - shingleLength; i++) {
			String together = words.get(i);
				for (int j = 1; j < shingleLength; j++) {	
					together += words.get(i + j);
				}
			result.add(together);
		}
		return result;
	}

	/**
	 * Returns the shingled word similarity of two texts.
	 * 
	 * The shingled word similarity is the Jaccard index between each text's
	 * shingle set.
	 * 
	 * A text's shingle set is the set of shingles (of the given length) for the
	 * entire text, as defined by shingle and asLowercaseWords, less the shingle
	 * set of the templateText. Removes the templateText from consideration
	 * after shingling, not before.
	 * 
	 * @param text1
	 * @param text2
	 * @param templateText
	 * @param shingleLength
	 * @return
	 */
	public static double shingleSimilarity(String text1, String text2, String templateText, int shingleLength) {
		List<String> listtext1 = new ArrayList<String>(asLowercaseWords(text1));
		List<String> listtext2 = new ArrayList<String>(asLowercaseWords(text2));
		Set<String> shingleset1 = shingle(listtext1,shingleLength);
		System.out.println(shingleset1);
		Set<String> shingleset2 = shingle(listtext2,shingleLength);
		System.out.println(shingleset2);
		List<String> settempl = new ArrayList<String>(asLowercaseWords(templateText));
		Set<String> settemp = shingle(settempl, shingleLength);
		System.out.println(settemp);
		shingleset1.removeAll(settemp);
		System.out.println(shingleset1);
		shingleset2.removeAll(settemp);
		System.out.println(shingleset2);
		double result = jaccardIndex(shingleset1, shingleset2);
		System.out.println(result);
		return result;
	}
}
