/*
 * Copyright 2017 Marc Liberatore.
 */

package sequencer;

public class Fragment {
	private String fragment;

	/**
	 * Creates a new Fragment based upon a String representing a sequence of
	 * nucleotides, containing only the uppercase characters G, C, A and T.
	 * 
	 * @param nucleotides
	 * @throws IllegalArgumentException
	 *             if invalid characters are in the sequence of nucleotides
	 */
	public Fragment(String nucleotides) throws IllegalArgumentException {
		boolean result = false;
		for (int i = 0; i < nucleotides.length(); i++) {
			if (nucleotides.charAt(i) == 'G' || nucleotides.charAt(i) == 'C' || nucleotides.charAt(i) == 'A'
					|| nucleotides.charAt(i) == 'T') {
				result = true;
			} else {
				result = false;
				break;
			}
		}
		if (result == false) {
			throw new IllegalArgumentException("Invalid character");
		}
		this.fragment = nucleotides;
	}

	/**
	 * Returns the length of this fragment.
	 * 
	 * @return the length of this fragment
	 */
	public int length() {
		return fragment.length();
	}

	/**
	 * Returns a String representation of this fragment, exactly as was passed
	 * to the constructor.
	 * 
	 * @return a String representation of this fragment
	 */
	@Override
	public String toString() {
		return fragment;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fragment == null) ? 0 : fragment.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Fragment other = (Fragment) obj;
		if (fragment == null) {
			if (other.fragment != null)
				return false;
		} else if (!fragment.equals(other.fragment))
			return false;
		return true;
	}

	/**
	 * Returns the number of nucleotides of overlap between the end of this
	 * fragment and the start of another fragment, f.
	 * 
	 * The largest overlap is found, for example, CAA and AAG have an overlap of
	 * 2, not 1.
	 * 
	 * @param f
	 *            the other fragment
	 * @return the number of nucleotides of overlap
	 */
	public int calculateOverlap(Fragment f) {
		int count = 0;
		int length = f.length();
		if (fragment.length() <= f.length()) {
			length = fragment.length();
		}
		for (int i = 1; i <= length; i++) {
			if (fragment.toString().substring(length-i,length).equals(f.toString().substring(0,i))) {
				count = i;
			}
		}
		return count;
	}

	/**
	 * Returns a new fragment based upon merging this fragment with another
	 * fragment f.
	 * 
	 * This fragment will be on the left, the other fragment will be on the
	 * right; the fragments will be overlapped as much as possible during the
	 * merge.
	 * 
	 * @param f
	 *            the other fragment
	 * @return a new fragment based upon merging this fragment with another
	 *         fragment
	 */
	public Fragment mergedWith(Fragment f) {
		int overlap = this.calculateOverlap(f);
		Fragment result = new Fragment(this+f.toString().substring(overlap));
		return result;
	}
}
