/*
 * Copyright 2017 Marc Liberatore.
 */

package sequencer;

import java.util.ArrayList;
import java.util.List;

public class Assembler {
	List<Fragment> list = new ArrayList<Fragment>();

	/**
	 * Creates a new Assembler containing a list of fragments.
	 * 
	 * The list is copied into this assembler so that the original list will not
	 * be modified by the actions of this assembler.
	 * 
	 * @param fragments
	 */
	public Assembler(List<Fragment> fragments) {
		for(Fragment frag:fragments ) {
			list.add(frag);
		}
	}

	/**
	 * Returns the current list of fragments this assembler contains.
	 * 
	 * @return the current list of fragments
	 */
	public List<Fragment> getFragments() {
		return list; 
	}

	/**
	 * Attempts to perform a single assembly, returning true iff an assembly was
	 * performed.
	 * 
	 * This method chooses the best assembly possible, that is, it merges the`
	 * two fragments with the largest overlap, breaking ties between merged
	 * fragments by choosing the shorter merged fragment.
	 * 
	 * Merges must have an overlap of at least 1.
	 * 
	 * After merging two fragments into a new fragment, the new fragment is
	 * inserted into the list of fragments in this assembler, and the two
	 * original fragments are removed from the list.
	 * 
	 * @return true iff an assembly was performed
	 */
	public boolean assembleOnce() {
		int compare = 0;
		int position = 0;
		int target = 0;
		for(int i = 0; i < list.size();i++) {
			/**if(list.get(i).calculateOverlap(list.get(i+1)) > compare) {
				compare = list.get(i).calculateOverlap(list.get(i+1));
			 */
			for(int n = i; n < list.size() - 1;n++) {
				if(list.get(i).calculateOverlap(list.get(n+1)) > compare ||list.get(n+1).calculateOverlap(list.get(i)) > compare ) {
					if(list.get(i).calculateOverlap(list.get(n+1)) > list.get(n+1).calculateOverlap(list.get(i))){
						compare = list.get(i).calculateOverlap(list.get(n+1));
						position = i;
						target = n+1;
					}else {
						compare =list.get(n+1).calculateOverlap(list.get(i));
						position = n+1;
						target =i;
					}

				}
			}
		}
		if(compare > 0) {
			Fragment finalfragment1 = list.get(position);
			Fragment finalfragment2 = list.get(target);
			Fragment res = finalfragment1.mergedWith(finalfragment2);
			list.remove(finalfragment1);
			list.remove(finalfragment2);
			list.add(res);
			/**
			System.out.println("finalfragment1: "+finalfragment1+"\r\n");
			System.out.println("finalfragment2: "+finalfragment2+"\r\n");
			System.out.println("merge result: "+res+"\r\n");
			 */
			return true;
		}
		return false;
	}


	/**
	 * Repeatedly assembles fragments until no more assembly can occur.
	 */
	public void assembleAll() {
		while(assembleOnce()) {
			assembleOnce();
		}
	}
}
