/*
 * Copyright 2017 Marc Liberatore.
 */

package log;

import log.SuspectEntry;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.opencsv.CSVReader;

public class LogParser {
	/**
	 * Returns a list of SuspectEntries corresponding to the CSV data supplied
	 * by the given Reader.
	 * 
	 * The data contains one or more lines of the format:
	 * 
	 * Marc,413-545-3061,1234567890
	 * 
	 * representing a name, phone number, and passport number.
	 * 
	 * @param r
	 *            an open Reader object
	 * @return a list of SuspectEntries
	 * @throws IOException
	 */
	public static List<SuspectEntry> parseLog(Reader r) throws IOException {
		List<SuspectEntry> result = new ArrayList<>();
		CSVReader csv = new CSVReader(r);
		List<String[]> csvlist = csv.readAll();
		for (String[] i : csvlist) {
			result.add(new SuspectEntry(i[0], i[1], i[2]));
		}
		return result;
	}

	/**
	 * Returns a sorted list of SuspectEntries whose passport numbers are common to all 
	 * of the supplied entryLists.
	 * 
	 * The list is sorted lexicographically by passport number, breaking ties by name 
	 * and then by phone number.
	 * 
	 * @param entryLists a list of lists of SuspectEntries
	 * @return a sorted list of SuspectEntries whose passport numbers are common to all 
	 * of the supplied entryLists
	 */
	public static List<SuspectEntry> findCommonEntries(List<List<SuspectEntry>> entryLists) {
		List<String> passportList = new ArrayList<>();
//		List<Integer> findnumber = new ArrayList<>();
		List<SuspectEntry> result = new ArrayList<>();
		Set<String> passport = new HashSet<String>();
		if (entryLists.isEmpty()) {
			return result;
		}
		for(List<SuspectEntry> passportlist1 : entryLists){
			for(int i = 0; i < passportlist1.size(); i++){
				SuspectEntry passportlist2 = passportlist1.get(i);
//				if (!passportList.contains(passportlist2.getPassport())) {
//					result.add(passportlist2);
					passport.add(passportlist2.getPassport());
//					findnumber.add(0);
			}
		}
		
		for(String passportnum : passport){
			for(List<SuspectEntry> num : entryLists){
				boolean re = true;
				for(SuspectEntry passnm : num){
					if(passportnum.equals(passnm.getPassport())){
						re = false;
					}
				}
				if(re){
					passportList.add(passportnum);
				}
			}
		}
		passport.removeAll(passportList);
		for(List<SuspectEntry> pass : entryLists){
			for(SuspectEntry passPort : pass){
				if(passport.contains(passPort.getPassport())&& !result.contains(passPort)){
					result.add(passPort);
				}
			}
		}
		result.sort(null);
		return result;
	}
}