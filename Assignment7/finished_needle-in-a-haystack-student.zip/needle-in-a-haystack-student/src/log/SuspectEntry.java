/*
 * Copyright 2017 Marc Liberatore.
 */

package log;

import java.util.Comparator;

public class SuspectEntry implements Comparable<SuspectEntry> {
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SuspectEntry other = (SuspectEntry) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (passportNumber == null) {
			if (other.passportNumber != null)
				return false;
		} else if (!passportNumber.equals(other.passportNumber))
			return false;
		if (phoneNumber == null) {
			if (other.phoneNumber != null)
				return false;
		} else if (!phoneNumber.equals(other.phoneNumber))
			return false;
		return true;
	}

	private String name;
	private String phoneNumber;
	private String passportNumber;
	
	public SuspectEntry(String name, String phoneNumber, String passportNumber) {
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.passportNumber = passportNumber;
	}
	public String getName(){
		return this.name;
	}
	public String getPhone(){
		return this.phoneNumber;
	}
	public String getPassport(){
		return this.passportNumber;
	}

	@Override
	public int compareTo(SuspectEntry o2) {
		if (this.getPassport().compareTo(o2.getPassport()) < 0) {		
			return -1;
		}
		if (this.getPassport().compareTo(o2.getPassport()) > 0) {
			return 1;
		}
		if (this.getPassport().compareTo(o2.getPassport()) == 0) {
			if (this.getName().compareTo(o2.getName()) < 0) {	
				return -1;
			}
			if (this.getName().compareTo(o2.getName()) > 0) {	
				return 1;
			}
			if (this.getName().compareTo(o2.getName()) == 0) {	
				if (this.getPhone().compareTo(o2.getPhone()) < 0) {	
					return -1;
				}				
				if (this.getPhone().compareTo(o2.getPhone()) > 0) {					
					return 1;
				}
			}
		}		
		return 0;
	}
}
