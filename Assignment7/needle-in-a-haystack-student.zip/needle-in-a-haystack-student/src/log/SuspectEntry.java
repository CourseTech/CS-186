/*
 * Copyright 2017 Marc Liberatore.
 */

package log;

public class SuspectEntry {
	
	public SuspectEntry(String name, String phoneNumber, String passportNumber) {
	}

}
