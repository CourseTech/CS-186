/*
 * Copyright 2017 Marc Liberatore.
 */

package simulator;

public class Bus {
	public final int number;
	private final RoadMap roadMap;
	private int x;
	private int y;
	public int North = 0;
	public int South = 0;
	public int West = 0;
	public int East = 0;
	public int pathx = 0;
	public int pathy = 0;
	public int i = 0;

	public Bus(int number, RoadMap roadMap, int x, int y) {
		this.number = number;
		this.roadMap = roadMap;
		this.x = x;
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	/**
	 * Move the bus. Buses only move along the cardinal directions
	 * (north/south/east/west), not diagonally.
	 * 
	 * If the bus is stopped (that is, if it was just placed, or if it didn't
	 * move last time move() was called), then it should attempt to move north.
	 * If it cannot (no road, or off the map), then it should attempt south,
	 * then east, then west. If no move is available, it should stay in its
	 * current position.
	 * 
	 * If the bus is moving (that is, if it successfully moved the last time
	 * move() was called), then it should attempt to continue moving in the same
	 * direction.
	 * 
	 * If it cannot (no road, or off the map), then it should attempt to turn
	 * right. For example, if the bus was moving north, but there is no more
	 * road to the north, it should move east if possible.
	 * 
	 * If it cannot turn right, it should turn left. If it cannot turn left, it
	 * should reverse direction (that is, move backward, if possible). 
	 * If it cannot do any of these things, it should stay in its current position.
	 */
	public void move(){
		if(i > 0){
			if(North > 0){
				if((y > 0)&&(roadMap.isRoad(x,y-1))){
					y--;
				}else if((x != roadMap.xSize-1)&&(roadMap.isRoad((x+1),y))){
					x++;
					North = 0;
					East++;
				}else if((x > 0) &&(roadMap.isRoad((x-1),y))){
					x--;
					North = 0;
					West++;
				}else if((y != roadMap.ySize-1)&&(roadMap.isRoad(x,(y+1)))){
					y++;
					North  = 0;
					South++;
				}
			}else if(South > 0){
				if((y != roadMap.ySize-1)&&(roadMap.isRoad(x,(y+1)))){
					y++;
				}else if((x > 0)&&(roadMap.isRoad((x-1),y))){
					x--;
					South =0;
					West++;
				}else if((x != roadMap.xSize-1)&&(roadMap.isRoad((x+1),y))){
					x++;
					South =0;
					East++;
				}else if((y > 0)&&(roadMap.isRoad(x,y-1))){
					y--;
					South = 0;
					North++;
				}
			}else if(East > 0){
				if((x != roadMap.xSize-1)&&(roadMap.isRoad((x+1),y))){
					x++;
				}else if((y != roadMap.ySize-1)&&(roadMap.isRoad(x,(y+1)))){
					y++;
					East = 0;
					South++;
				}else if((y > 0)&&(roadMap.isRoad(x,y-1))){
					y--;
					East = 0;
					North++;
				}else if((x > 0)&&(roadMap.isRoad((x-1),y))){
					x--;
					East = 0;
					West++;
				}	
			}else if(West > 0){
				if((x > 0)&&(roadMap.isRoad((x-1),y))){
					x--;	
				}else if((y != roadMap.ySize-1)&&(roadMap.isRoad(x,(y+1)))){
					y++;
					West = 0;
					South++;
				}else if((y > 0)&&(roadMap.isRoad(x,y-1))){
					y--;
					West = 0;
					North++;
				}else if((x != roadMap.xSize-1)&&(roadMap.isRoad((x+1),y))){
					x++;
					West = 0;
					East++;
				}
			}
		}
		if(i == 0){
			if((y > 0)&&(roadMap.isRoad(x,y-1))){
				y--;
				North ++;
			}else if((y != roadMap.ySize-1)&&(roadMap.isRoad(x,(y+1)))){
				y++;
				South ++;
			}else if((x != roadMap.xSize-1)&&(roadMap.isRoad((x+1),y))){
				x++;
				East ++;
			}else if((x > 0)&&(roadMap.isRoad((x-1),y))){
				x--;	
				West ++;
			}		
		i++;
		}
	}
}