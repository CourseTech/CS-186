/*
 * Copyright 2017 Marc Liberatore.
 */

package scheduler;

import java.util.ArrayList;
import java.util.List;

public class Scheduler {
	/**
	 * Instantiates a new, empty scheduler.
	 */
	private List<Course> scourse;
	private List<Student> sstudent;

	public Scheduler() {
		scourse = new ArrayList<Course>();
		sstudent = new ArrayList<Student>();
	}

	/**
	 * Adds a course to the scheduler.
	 * 
	 * @param course
	 *            the course to be added
	 */

	public void addCourse(Course course) {
		scourse.add(course);
	}

	/**
	 * Returns the list of courses that this scheduler knows about.
	 * 
	 * This returned object does not share state with the internal state of the
	 * Scheduler.
	 *
	 * @return the list of courses
	 */
	public List<Course> getCourses() {
		ArrayList<Course> Course = new ArrayList<Course>(scourse);
		return Course;
	}

	/**
	 * Adds a student to the scheduler.
	 * 
	 * @param student
	 *            the student to add
	 */
	public void addStudent(Student student) {
		sstudent.add(student);
	}

	/**
	 * Returns a list of the students this scheduler knows about.
	 * 
	 * This returned object does not share state with the internal state of the
	 * Scheduler.
	 * 
	 * @return
	 */

	public List<Student> getStudents() {
		ArrayList<Student> student = new ArrayList<Student>(sstudent);
		return student;
	}

	/**
	 * Assigns all students to courses in the following manner:
	 * 
	 * For a given student, check their list of preferred courses. Add them to
	 * the course that: - exists in the scheduler's list of courses - the
	 * student most prefers (that is, comes first in their preference list) -
	 * the student is not not already enrolled in - and is not full (in other
	 * words, at capacity) Adds courses to the *end* of the student's current
	 * list of classes. Adds students to the *end* of the course's roster.
	 * 
	 * Repeat this process for each student, one-by-one; each student will now
	 * have one course, usually (but not always) their most preferred course.
	 * 
	 * Then repeat this whole process (adding one course per student, when
	 * possible, proceeding round-robin among students), until there is nothing
	 * left to do: Students might all be at their maximum number of courses, or
	 * there may be no available seats in courses that students want.
	 */
	public void assignAll() {
		int a = 0;
		int capacity[] = new int[this.getCourses().size()];
		for (int i = 0; i < this.getCourses().size(); i++) {
			capacity[i] = this.getCourses().get(i).getCapacity();
		}
		for (int count = 0; count < this.getCourses().size(); count++) {
			for (Student name : this.getStudents()) {
				Course Coursei = name.getPreferences().get(a);
				if (this.getCourses().indexOf(Coursei) == -1) {
					continue;
				}

				int b = this.getCourses().indexOf(Coursei);
				while (b + 1 < this.getCourses().size()) {
					if (capacity[b] == 0 || name.getSchedule().indexOf(this.getCourses().get(b)) != -1) {
						b++;
					} else {
						break;
					}
				}

				if (name.getSchedule().size() < name.getMaxCourses()) {
					if (capacity[b] > 0 && this.getCourses().get(b).getRoster().indexOf(name) == -1) {
						name.addSchedule(this.getCourses().get(b));
						this.getCourses().get(b).addRoster(name);
						capacity[b]--;
						this.getCourses().get(b).minusCapacity();
					}
				}
			}
			a++;
		}
	}

	/**
	 * Drops a student from a course.
	 * 
	 * @param student
	 * @param course
	 * @throws IllegalArgumentException
	 *             if either the student or the course are not known to this
	 *             scheduler
	 */
	public void drop(Student student, Course course) throws IllegalArgumentException {
		if (this.getCourses().indexOf(course) == -1 || this.getStudents().indexOf(student) == -1) {
			throw new IllegalArgumentException();
		}
		student.removeCourse(course);
		course.removeRoster(student);
		course.addCapacity();
	}

	/**
	 * Drops a student from all of their courses.
	 * 
	 * @param student
	 * @throws IllegalArgumentException
	 *             if the student is not known to this scheduler
	 */
	public void unenroll(Student student) throws IllegalArgumentException {
		if (this.getStudents().indexOf(student) == -1) {
			throw new IllegalArgumentException();
		}

		while (student.getSchedule().size() != 0) {
			student.getSchedule().get(0).addCapacity();
			student.getSchedule().get(0).removeRoster(student);
			student.removeCourse(student.getSchedule().get(0));
		}
	}
}
