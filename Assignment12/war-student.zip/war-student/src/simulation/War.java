/*
 * Copyright 2017 Marc Liberatore.
 */

package simulation;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * 
 * A Java class to simulate the card game War. See assignment writeup for details.
 * 
 * @author liberato
 *
 */
public class War {
	/**
	 * Determines the winner of a game of War, returning 1 if player A wins, -1 if player B wins, 0 if a draw.
	 * 
	 * The rules of the game are defined in the assignment writeup.
	 * 
	 * @param deck
	 * @return 1 if player A wins, -1 if player B wins, 0 if a draw
	 */
	public static int findWinner(List<Integer> deck) {
		return 0;
	}
}
