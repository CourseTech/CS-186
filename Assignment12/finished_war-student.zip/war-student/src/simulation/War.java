/*
 * Copyright 2017 Marc Liberatore.
 */

package simulation;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * A Java class to simulate the card game War. See assignment writeup for
 * details.
 * 
 * @author liberato
 *
 */
public class War {
	/**
	 * Determines the winner of a game of War, returning 1 if player A wins, -1
	 * if player B wins, 0 if a draw.
	 * 
	 * The rules of the game are defined in the assignment writeup.
	 * 
	 * @param deck
	 * @return 1 if player A wins, -1 if player B wins, 0 if a draw
	 */
	public List<Integer> deck = new ArrayList<>();
	private List<Integer> Acard = new ArrayList<>();
	private List<Integer> Bcard = new ArrayList<>();
	public List<Integer> temppile = new ArrayList<>();
	public int outcome = 0;
	public int battlecount = 0;

	public War(List<Integer> deck) {
		this.deck = deck;
		int index = 0;
		for (int i = 0; i < (deck.size() + 1) / 2; i++) {
			Acard.add(deck.get(index));
			if (index < deck.size() - 1) {
				index++;
			} else {
				break;
			}
			Bcard.add(deck.get(index));
			index++;
		}
	}

	public static int findWinner(List<Integer> deck) {
		War w = new War(deck);
		return w.simulateGame();
	}

	public int simulateGame() {
		battle();
		return this.outcome;
	}

	public boolean isgameOver() {
		boolean result = false;
		if (battlecount == 1000) {
			result = true;
			this.outcome = 0;
		}

		else if (this.Acard.size() == 0) {
			if (this.Bcard.size() == 0) {
				this.outcome = 0;
			} else {
				this.outcome = -1;
			}
			result = true;
		} else if (Bcard.size() == 0) {
			this.outcome = 1;
			result = true;
		}

		return result;
	}

	public void battle() {
		while (!isgameOver()) {
			this.battlecount++;
			this.temppile.add(Acard.get(0));
			this.temppile.add(Bcard.get(0));
			if (Acard.get(0) == Bcard.get(0)) {
				Acard.remove(0);
				Bcard.remove(0);
				if (!isgameOver()) {
					war();
				}
			} else if (Acard.get(0) > Bcard.get(0)) {
				Acard.remove(0);
				Bcard.remove(0);
				Acard.addAll(temppile);
				temppile.clear();
			} else if (Acard.get(0) < Bcard.get(0)) {
				Acard.remove(0);
				Bcard.remove(0);
				Bcard.addAll(temppile);
				temppile.clear();
			}
		}

	}

	public void war() {
		if (Acard.size() < 3) {
			if (Bcard.size() < 3) {
				Acard.clear();
				Bcard.clear();
			} else {
				Acard.clear();
			}
		} else if (Bcard.size() < 3) {
			Bcard.clear();
		}

		if (!isgameOver()) {
			this.temppile.add(Acard.remove(0));
			this.temppile.add(Acard.remove(0));
			this.temppile.add(Acard.remove(0));
			// Acard.removeAll(Acard.subList(0, 3));
			// Acard.remove(0);
			// Acard.remove(0);
			// Acard.remove(0);

			// temppile.addAll(Bcard.subList(0, 3));
			// Bcard.removeAll(Bcard.subList(0, 3));
			this.temppile.add(Bcard.remove(0));
			this.temppile.add(Bcard.remove(0));
			this.temppile.add(Bcard.remove(0));
			// Bcard.remove(0);
			// Bcard.remove(0);
			// Bcard.remove(0);
		}
	}

	public static void main(String argus[]) {
		List<Integer> deck = new ArrayList<>();
		for (int i = 0; i < 4 * 1000 * 2; i++) {
			deck.add(i);
			deck.add(i + 1);
		}
		// deck.add(1);
		// deck.add(1);
		// deck.add(1);
		// deck.add(1);
		// deck.add(1);
		// deck.add(1);
		// deck.add(1);
		// deck.add(1);
		// deck.add(1);
		// deck.add(3);
		// deck.add(5);
		// deck.add(1);
		// deck.add(2);
		// deck.add(4);
		// deck.add(2);
		// deck.add(0);
		War w = new War(deck);
		w.battle();
		System.out.println(w.Acard);
		System.out.println(w.Bcard);
		System.out.println(w.battlecount);
		System.out.println(findWinner(deck));
	}
}
