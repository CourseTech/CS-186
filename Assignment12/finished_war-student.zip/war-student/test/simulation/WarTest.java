/*
 * Copyright 2017 Marc Liberatore.
 */

package simulation;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class WarTest {
	@Test
	public void testEmpty() {
		assertEquals(0, War.findWinner(new ArrayList<Integer>()));
	}

	@Test
	public void testOne() {
		List<Integer> deck = Arrays.asList(2);
		assertEquals(1, War.findWinner(deck));
	}

	@Test
	public void testTwoA() {
		List<Integer> deck = Arrays.asList(3, 2);
		assertEquals(1, War.findWinner(deck));
	}

	@Test
	public void testTwoB() {
		List<Integer> deck = Arrays.asList(2, 3);
		assertEquals(-1, War.findWinner(deck));
	}

	@Test
	public void testTwoEqual() {
		List<Integer> deck = Arrays.asList(2, 2);
		assertEquals(0, War.findWinner(deck));
	}

	@Test
	public void testExample() {
		List<Integer> deck = Arrays.asList(2, 3, 4, 5);
		assertEquals(-1, War.findWinner(deck));
	}

}
