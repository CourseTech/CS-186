/*
 * Copyright 2017 Marc Liberatore.
 */

package index;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import comparators.TfIdfComparator;
import documents.DocumentId;

/**
 * A simplified document indexer and search engine.
 * 
 * Documents are added to the engine one-by-one, and uniquely identified by a DocumentId.
 *
 * Documents are internally represented as "terms", which are lowercased versions of each word 
 * in the document. 
 * 
 * Queries for terms are also made on the lowercased version of the term. Terms are 
 * therefore case-insensitive.
 * 
 * Lookups for documents can be done by term, and the most relevant document(s) to a specific term 
 * (as computed by tf-idf) can also be retrieved.
 *
 * See:
 * - <https://en.wikipedia.org/wiki/Inverted_index>
 * - <https://en.wikipedia.org/wiki/Search_engine_(computing)> 
 * - <https://en.wikipedia.org/wiki/Tf%E2%80%93idf>
 * 
 * @author Marc Liberatore
 *
 */
public class SearchEngine{
//	private static final String PAELLA = "Paella (Catalan pronunciation: [paˈeʎa] or [pəˈeʎə], Spanish: [paˈeʎa]; English approximation: /pɑːˈeɪlə, -ˈeɪljə, -ˈeɪjə, -ˈɛlə, -ˈjɛlə/ or /paɪˈɛlə/) is a Valencian rice dish with ancient roots that originated in its modern form in the mid-19th century near Albufera lagoon on the east coast of Spain adjacent to the city of Valencia. Many non-Spaniards view paella as Spain's national dish, but most Spaniards consider it to be a regional Valencian dish. Valencians, in turn, regard paella as one of their identifying symbols. Valencian paella is believed to be the original recipe and consists of white rice, green beans (bajoqueta and tavella), meat (chicken and rabbit), white beans (garrofón), snails, and seasoning such as saffron and rosemary. Another very common but seasonal ingredient is artichokes. Seafood paella replaces meat with seafood and omits beans and green vegetables. Mixed paella is a free-style combination of meat from land animals, seafood, vegetables, and sometimes beans. Most paella chefs use bomba rice due to it being harder to overcook, but Valencians tend to use a slightly stickier (and thus more susceptible to overcooking) variety known as Senia. All types of paellas use olive oil.";
//	private static final DocumentId PAELLA_ID = new DocumentId("PAELLA");
//	private static final String FRIED_RICE = "Fried rice (Chinese: 炒飯; pinyin: chǎo fàn) is a Chinese dish of steamed rice that has been stir-fried in a wok and, usually, mixed with other ingredients, such as eggs, vegetables, and meat, and as such, often served as a complete dish. It is sometimes served as the penultimate dish in Chinese banquets, just before dessert. As a homemade dish, fried rice is typically made with leftover ingredients (including vegetables and/or meat) from other dishes, leading to countless variations, being an economic hodgepodge like it is done with fried noodles or pyttipanna.";
//	private static final DocumentId FRIED_RICE_ID = new DocumentId("FRIED_RICE");
//	private static final String CHOW_MEIN = "Chow mein (/ˈtʃaʊ ˈmeɪn/) are stir-fried noodles, the name being the romanization of the Taishanese chāu-mèing. The dish is popular throughout the Chinese diaspora and appears on the menus of Chinese restaurants.In American Chinese cuisine, it is a stir-fried dish consisting of noodles, meat (chicken being most common but pork, beef, shrimp or tofu sometimes being substituted), onions and celery. It is often served as a specific dish at westernized Chinese restaurants. Vegetarian or vegan Chow Mein is also common.";
//	private static final DocumentId CHOW_MEIN_ID = new DocumentId("CHOW_MEIN");
//	private static final String TOMATO_SAUCE = "Tomato sauce (also known as Neapolitan sauce, and referred to in Italy as Napoletana sauce), refers to any of a very large number of sauces made primarily from tomatoes, usually to be served as part of a dish (rather than as a condiment). Tomato sauces are common for meat and vegetables, but they are perhaps best known as sauces for pasta dishes.";
//	private static final DocumentId TOMATO_SAUCE_ID = new DocumentId("TOMATO_SAUCE");
	

	public Map<String, Set<DocumentId>> map = new HashMap<>();
	public Map<DocumentId,Map<String,Integer>> freMap= new HashMap<>();
	/**
	 * Inserts a document into the search engine for later analysis and retrieval.
	 * 
	 * The document is uniquely identified by a documentId; attempts to re-insert the same 
	 * document are ignored.
	 * 
	 * The document is supplied as a Reader; this method stores the document contents for 
	 * later analysis and retrieval.
	 * 
	 * @param documentId
	 * @param reader
	 * @throws IOException iff the reader throws an exception 
	 */
	public void addDocument(DocumentId documentId, Reader reader) throws IOException {
		BufferedReader br = new BufferedReader(reader);
		Map<String, Integer> freMapOne = new HashMap<>();
		for (String line = br.readLine(); line != null; line = br.readLine()){
			line = line.toLowerCase();
			String[] newtext = line.split("\\W+");
			int count = 0;
			for (String text : newtext) {
				String newline = text.trim();
				if (newline.length() > 0) {
					if(map.containsKey(newline)){
						if(!map.get(newline).contains(documentId)){
							map.get(newline).add(documentId);
							freMapOne.put(newline, 1);
						}else{
							count = freMapOne.get(newline);
							count ++;
							freMapOne.put(newline, count);
						}
					}else{
						Set<DocumentId> Doc = new HashSet<>();
						Doc.add(documentId);
						map.put(newline,Doc);
						freMapOne.put(newline, 1);
					}
					
				}
			}	
		}
		freMap.put(documentId, freMapOne);
	}

	/**
	 * Returns the set of DocumentIds contained within the search engine that contain a given term.
	 * 
	 * @param term
	 * @return the set of DocumentIds that contain a given term
	 */
	public Set<DocumentId> indexLookup(String term) {
		term = term.toLowerCase();
		Set<DocumentId> result = new HashSet<>();	
		result = map.getOrDefault(term, result);
		return result;
	}
	
	/**
	 * Returns the term frequency of a term in a particular document.
	 * 
	 * The term frequency is number of times the term appears in a document.
	 * 
	 * See 
	 * @param documentId
	 * @param term
	 * @return the term frequency of a term in a particular document
	 * @throws IllegalArgumentException if the documentId has not been added to the engine
	 */
	public int termFrequency(DocumentId documentId, String term) throws IllegalArgumentException {
		int result = 0;
		Map<String,Integer> fre = new HashMap<>();
		if(!freMap.containsKey(documentId)){
			throw new IllegalArgumentException();
		}
		fre.putAll(freMap.get(documentId));
		result = fre.getOrDefault(term, 0);
		return result;
	}
	
	/**
	 * Returns the inverse document frequency of a term across all documents in the index.
	 * 
	 * For our purposes, IDF is defined as log ((1 + N) / (1 + M)) where 
	 * N is the number of documents in total, and M
	 * is the number of documents where the term appears.
	 * 
	 * @param term
	 * @return the inverse document frequency of term 
	 */
	public double inverseDocumentFrequency(String term) {
		double result = 0.0;
		double n = freMap.keySet().size();
		double m = 0;
		for(DocumentId Doc : freMap.keySet()){
			if(termFrequency(Doc,term) > 0){
				m++;
			}
		}
		result = Math.log(((1 + n) / (1 + m)));
		return result;
	}
	
	/**
	 * Returns the tfidf score of a particular term for a particular document.
	 * 
	 * tfidf is the product of term frequency and inverse document frequency for the given term and document.
	 * 
	 * @param documentId
	 * @param term
	 * @return the tfidf of the the term/document
	 * @throws IllegalArgumentException if the documentId has not been added to the engine
	 */
	public double tfIdf(DocumentId documentId, String term) throws IllegalArgumentException {
		double result = 0.0;
		double idf = inverseDocumentFrequency(term);
		double tf = termFrequency(documentId, term);
		result = idf * tf;
		return result;
	}
	
	/**
	 * Returns a sorted list of documents, most relevant to least relevant, for the given term.
	 * 
	 * A document with a larger tfidf score is more relevant than a document with a lower tfidf score.
	 * 
	 * Each document in the returned list must contain the term.
	 * 
	 * @param term
	 * @return a list of documents sorted in descending order by tfidf
	 */
	public List<DocumentId> relevanceLookup(String term){
		List<DocumentId> result = new ArrayList<>();
		result.addAll(indexLookup(term));
//		TfIdfComparator.sort(result);
		result.sort(new TfIdfComparator(this,term));
		return result;
		
	}
//	public List<DocumentId> relevanceLookup(String term){
//		List<DocumentId> result = new ArrayList<>();
//		result.addAll(indexLookup(term));
//		Collections.sort(result, new comparator)
//		return result;
//	}
}
