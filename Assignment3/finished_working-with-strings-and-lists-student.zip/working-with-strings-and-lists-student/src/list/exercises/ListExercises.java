/*
 * Copyright 2017 Marc Liberatore.
 */

package list.exercises;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListExercises {

	/**
	 * Counts the number of characters in total across all strings in the
	 * supplied list; in other words, the sum of the lengths of the all the
	 * strings.
	 * 
	 * @param l
	 *            a non-null list of strings
	 * @return
	 * @return the number of characters
	 */
	public static int countCharacters(List<String> l) {
		int a = l.size();
		int count = 0;
		for (int i = 0; i < a; i++) {
			count += (l.get(i)).length();
		}
		return count;
	}

	/**
	 * Splits a string into words and returns a list of the words. If the string
	 * is empty, split returns a list containing an empty string.
	 * 
	 * @param s
	 *            a non-null string of zero or more words
	 * @return a list of words
	 */
	public static List<String> split(String s) {
		String[] splitword = s.split("\\s+");
		List<String> list = Arrays.asList(splitword);
		return list;
	}

	/**
	 * Returns a copy of the list of strings where each string has been
	 * uppercased (as by String.toUpperCase).
	 * 
	 * The original list is unchanged.
	 * 
	 * @param l
	 *            a non-null list of strings
	 * @return a list of uppercased strings
	 */
	public static List<String> uppercased(List<String> l) {
		int i = l.size();
		String[] up = (String[]) l.toArray(new String[i]);
		for (int a = 0; a < i; a++) {
			up[a] = up[a].toUpperCase();
		}
		List<String> list = Arrays.asList(up);
		return list;
	}

	/**
	 * Returns true if and only if each string in the supplied list of strings
	 * starts with an uppercase letter. If the list is empty, returns false.
	 * 
	 * @param l
	 *            a non-null list of strings
	 * @return true iff each string starts with an uppercase letter
	 */
	public static boolean allCapitalizedWords(List<String> l) {
		int i = l.size();
		if (l.isEmpty()) {
			return false;
		}
		String[] all = (String[]) l.toArray(new String[i]);
		for (int a = 0; a < i; a++) {
			if(all[a]== null || all[a].length() == 0){
				return false;
			}
			if (!Character.isUpperCase(all[a].charAt(0))) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Returns a list of strings selected from a supplied list, which contain
	 * the character c.
	 * 
	 * The returned list is in the same order as the original list, but it omits
	 * all strings that do not contain c.
	 * 
	 * The original list is unmodified.
	 * 
	 * @param l
	 *            a non-null list of strings
	 * @param c
	 *            the character to filter on
	 * @return a list of strings containing the character c, selected from l
	 */
	public static List<String> filterContaining(List<String> l, char c) {
		int i = l.size();
		String newc = String.valueOf(c);
		List<String> list = new ArrayList<String>();
		String[] filter = (String[]) l.toArray(new String[i]);
		for (int a = 0; a < i; a++) {
			if(filter[a].contains(newc)){
			list.add(filter[a]);	
			}
		}
		return list;
	}

	/**
	 * Inserts a string into a sorted list of strings, maintaining the sorted
	 * property of the list.
	 * 
	 * @param s
	 *            the string to insert
	 * @param l
	 *            a non-null, sorted list of strings
	 */
	public static void insertInOrder(String s, List<String> l) {
		int i = l.size();
		int count = 0;
		String[] inorder = (String[]) l.toArray(new String[i]);
		for (int a = 0; a < i; a++) {
			if (inorder[a].compareTo(s) < 0) {
				count++;
			}else{
				break;	
			}
		}
		l.add(count,s);
	}
}
